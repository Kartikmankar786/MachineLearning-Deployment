import os
import pickle
from fastapi import FastAPI, HTTPException
import nest_asyncio
import pandas as pd
import uvicorn
from sklearn.pipeline import Pipeline
from pydantic import BaseModel

dir = r'C:\Users\kirti\OneDrive\Documents\Salary\Salary.pkl'
nest_asyncio.apply()
app = FastAPI()

def load_model():
    try:
        if not  os.path.exists(dir):
            raise FileNotFoundError(f'file not found{dir}')
        with open(dir,'rb') as model_file:
            model = pickle.load(model_file)
            
            if not isinstance(model,Pipeline):
                raise TypeError(f'model not loaded properly')
        return model
    except Exception as e:
        raise HTTPException(status_code=500,detail = str(e))
        
model = load_model()
class Sal(BaseModel):
    Age:int
    Gender:str
    Education:str
    Job:str
    Experience:int
    
    
@app.post('/predict')
def predict(data:Sal):
    try:
        print(f'recieve data:{data}')
        
        input_data = pd.DataFrame([[data.Age,data.Education,data.Experience,data.Gender,data.Job]],
                                  columns=['Age','Gender','Experience','Education','Job'])
        
        
        preprocessor=model.named_steps['preprocessor'].transform(input_data)
        prediction = model.named_steps['model'].predict(preprocessor)
        return {'prediction' : int(prediction[0])}
    except Exception as e:
        raise HTTPException(status_code=400,detail=str(e))
        
if __name__ == '__main__':
    uvicorn.run(app,host='127.0.0.1',port=8000)
    
        
        
        